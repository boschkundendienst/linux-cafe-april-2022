---
title: "Linux Cafe 04/2022"
controls: true
controlsTutorial: true
controlsLayout: "bottom-right"
slideNumber: true
theme: "night"
transition: "zoom"
highlightTheme: "monokai"
logoImg: "images/logo.png"
---

<!-- .slide: style="text-align:left;" data-background-image="images/background01.jpg" data-background-size="960x 700x" -->

## TiddlyWiki

#### Die "eierlegende Wollmilchsau" der Wikis

Linux Cafe am 06.04.2022

<br>

Diese Präsentation befindet sich im [Git-Repo](https://github.com/boschkundendienst/linux-cafe-april-2022) unter <small>`presentation/files/presentation.html`</small>

---

<!-- .slide: style="text-align:right;" data-background-image="images/big-head-small-man.jpg" data-background-size="960x 700x" -->

# vs. Brain

<div align="right"><font color="black">Hatten Sie schon mal das Gefühl,<br>Ihr Gehirn sei nicht groß genug,<br>um sich alles zu merken,<br>was Ihnen wichtig ist?</font></div>

<div align="right">
<small><font color="black">
Willkommen bei TiddlyWiki, dem einzigartigen nicht-linearen<br>
Web-Notizbuch, das Ihnen hilft Ihre Ideen zu sammeln,<br>
zu strukturieren und weiterzugeben.</small></div>
</font>

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle-white.png" data-background-size="960x 700x" -->

## TiddlyWiki

TiddlyWiki besteht aus sogenannten "Tiddlern". Die Philosophie eines Tiddlers ist es, die Möglichkeiten der Wiederverwendbarkeit zu maximieren.

Dies wird dadurch erreicht, dass Informationen in gerade so kleine Einheiten "zerlegt" werden, dass sie für sich genommen, noch Sinn machen.

---

<!-- .slide: style="text-align:left;font-size:40px;" data-background-image="images/puzzle-white.png" data-background-size="960x 700x" -->

### Warum TiddlyWiki?

<small>Ich habe viele Wikis ausprobiert. Obwohl es sehr gute Ansätze gibt, hat man meist das Problem, dass man einen Server oder Dienst benötigt um das Wiki zu benutzen oder zu betreiben.

Die Inhalte werden meistens in einer Datenbank gespeichert und sind nur verfügbar wenn mehrere Dienste (z.B. Webserver + Datenbank) funktionieren.

TiddlyWiki in seiner einfachsten Form besteht nur aus einer einzigen HTML-Datei, d.h. alles was ich benötige ist ein aktueller HTML5-Browser.

Tiddlywiki ist sehr zukunftssicher. Ein einmal erstelltes TiddlyWiki (eine HTML-Datei) wird auch in einigen Jahren noch von jedem HTML5 Browser darstellbar sein.
</small>

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/puzzle-white.png" data-background-size="960x 700x" -->

### Darum TiddlyWiki !

- von jedem bedienbar
- TiddlyWiki kann leicht an die eigenen Bedürfnisse angepasst werden
- Bilder und andere Dateien werden Base64-kodiert in der HTML-Datei gespeichert
- Export einzelner Tiddler (z.B. zur Weitergabe) möglich
- Upgrades sind nicht nötig aber möglich und sehr einfach.
- Alles in einer Datei aber jederzeit wieder "zerlegbar"
- Import von Bildern und Inhalten per Drag & Drop möglich

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/background05.png" data-background-size="960x 700x" -->

### Darum erst recht TiddlyWiki !

- Portabel
- bei Bedarf verschlüsselt (standalone Version)
- leicht zu bedienen
- einfach zu erlernen
- modular und hochgradig anpassbar
- Einfache und erweiterte Suche
- sehr gute Dokumentation
- Unterstützung von Bildern
- funktioniert auch auf Mobilgeräten

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/face001.jpg" data-background-size="960x 700x" -->

### Anwendungsmöglichkeiten

- Aufgaben-Manager
- Notizblock
- Manager für Teamprotokolle oder Chatlogs
- Persönliches Memo
- Tägliches Journal
- Code-Notizen
- Persönliche Gesundheitsakte
- Dokumentationen

---

<!-- .slide: style="text-align:left;" data-background-image="images/platforms.jpg" data-background-size="960x 700x" -->

### Plattformen

- TiddlyWiki in einer HTML-Datei
- **TiddlyDesktop** zum einfacheren Editieren und zur Verwaltung vieler TiddlyWiki-HTML-Dateien
- TiddlyWiki im Beaker Browser
- **TiddlyWiki on Node.js** - die "Server-Version"

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/background02.jpg" data-background-size="960x 700x" -->

## Demo - TiddlyWiki self-contained (1 Datei)

- die "sich-selbst-beinhaltende" Variante von TiddlyWiki besteht aus nur einer HTML-Datei. Sie kann mit jedem aktuellen Browser geöffnet werden.

- Nachteil beim Öffnen mit dem Browser: Die Datei muss bei Änderungen ständig "überspeichert" werden.

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/background02.jpg" data-background-size="960x 700x" -->

## Demo - TiddlyDesktop
Zur einfacheren Verwaltung von lokalen TiddlyWiki-HTML-Dateien empfiehlt sich die Software **TiddlyDesktop**. Sie erspart das ständige Überspeichern der HTML-Datei und legt automatisch Sicherungskopien an.

[https://github.com/Jermolene/TiddlyDesktop](https://github.com/Jermolene/TiddlyDesktop)

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/background02.jpg" data-background-size="960x 700x" -->

## Demo - TiddlyWiki on Node.js

- Die "Server-Variante" von TiddlyWiki ist dann sinnvoll, wenn Tiddler einer größeren Menge an Personen zugänglich gemacht werden sollen, z.B. als zentrale Dokumentations-Plattform in einer Firma.

- Alle können dann auch gleichzeitig neue Tiddler anlegen oder Tiddler bearbeiten. Rechteverwaltung ist möglich

- Das gleichzeitige Bearbeiten des gleichen Tiddlers ist nicht möglich.

- Aus der "Server-Variante" kann wieder eine einzelne TiddlyWiki-HTML-Datei (self-contained) erstellt werden und vieles mehr!

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/background02.jpg" data-background-size="960x 700x" -->

## Demo - TiddlyWiki mit Beaker Browser

Eigentlich für einen ganz anderen Anwendungsfall gebaut ermöglicht es der "Beaker Browser" ebenfalls eine lokale TiddlyWiki-Datei sauber zu managen.

Zusätzlich hat er das Feature das Wiki dann mit anderen Beaker-Browser-Nutzern zu teilen (wenn gewünscht).

[https://beakerbrowser.com/](https://beakerbrowser.com/)

---

<!-- .slide: style="text-align:left;" data-background-image="images/background06.png" data-background-size="960x 700x" -->

## Aber jetzt geht's los!

Ich werde nun zeigen, wie ich aus einem leeren TiddlyWiki meine derzeitige Vorlage erstellt habe.

Bitte beachten, dass das Tiddlywiki ggf. immer überspeichert werden muss, wenn Änderungen durchgeführt wurden.

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 01 TiddlyWiki herunterladen

- [englische Version herunterladen](https://tiddlywiki.com/#:GettingStarted%20Community)
- [deutsche Version herunterladen](https://tiddlywiki.com/languages/de-DE/index.html#ErsteSchritte:ErsteSchritte%20HelloThere)

Erstelle nach dem Herunterladen eine Kopie der Datei `empty.html` und benutze die Kopie für die weiteren Schritte.

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 02 Markdown und Highlight Plugin

- Control-Panel → Plugins → Get more plugins → Suchfeld "Markdown"
- Markdown und Highlight Plugin installieren.

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 03 Grundeinstellungen

- <b>Sprachen downloaden:</b><br>Control-Panel → Plugins → Get more plugins → Languages → Suchfeld "deutsch" → Paket "de-DE Deutsch (Deutschland)" installieren

- <b>Seitenleiste:</b><br>Control-Panel → Design → Theme Tweaks → Seitenleiste Darstellung → "Variable Story, fixe Seitenleiste" einstellen

- <b>Titel und Untertitel:</b><br>Control-Panel → Info → Basis → Titel und Untertitel usw. einstellen

---

<!-- .slide: style="text-align:left;font-size:25px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 04 TiddlyWiki "Tools" konfigurieren

- Seitenleiste → Tools → z.B. folgende Auswahl:
<br>
<img height="500" src="images/tiddlywikitools.png">


---

<!-- .slide: style="text-align:left;font-size:25px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 05 Der Reiter "Inhalt"

- neuer Tiddler mit Tag: <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">$:/tags/SideBar</span>

```
Titel      : Inhalt
Neuer Tag: $:/tags/SideBar
Typ        : -
Text       :

<!-- unterhalb kopieren -->
Wiki Content
<div class="tc-table-of-contents">
<<toc-selective-expandable "Inhalt" "!title[$:/config/NewJournal/Tags]sort[modified]">>
<!-- <<toc-selective-expandable "Inhalt" "!title[$:/config/NewJournal/Tags]sort[title]">> -->
</div>
<!-- oberhalb kopieren -->

zusätzlich: 
Feld einfügen  : list-before
Feld Text / Wert: $:/core/ui/SideBar/Open
```

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 06 Der Bereich "Aufgaben" A

- Tiddler 01 "Aufgaben" mit Tag: <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Inhalt</span>

```
Title       : Aufgaben
tag name(s) : Inhalt
Typ         : -
Text        : -
```

---

<!-- .slide: style="text-align:left;font-size:25px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 06 Der Bereich "Aufgaben" B

- Tiddler 02 "ToDo" mit Tag: <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Aufgaben</span>

```
Title       : ToDo
tag name(s) : Aufgaben
Typ         : -
Text        :
<!-- copy below here -->
<$list filter='[!has[draft.of]tag[task]!tag[done]sort[created]]'>
<$checkbox tag='done'> <$link to={{!!title}}>
<$view field='created' format='date' template='DDth mmm 0hh:0mm'/> - <$view field='title'/><br>
</$link>
</$checkbox>
</$list>
<!-- copy above here -->
```

---

<!-- .slide: style="text-align:left;font-size:25px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 06 Der Bereich "Aufgaben" C

- Tiddler 03 "Erledigt"

```
Title       : Erledigt
tag name(s) : Aufgaben
Tag         : -
Text        :
<!-- copy below here -->
<$list filter='[!has[draft.of]tag[task]tag[done]sort[created]]'>
<$checkbox tag='done'> ~~<$link to={{!!title}}><$view field='created' format='date' template='DDth mmm 0hh:0mm'/> - <$view field='title'/></$link>~~</$checkbox><br>
</$list>
<!-- copy above here -->
```

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 06 Arbeiten mit "Aufgaben" D

- Um eine neue Aufgabe hinzuzufügen, erzeuge einfach einen neuen Tiddler und weise ihm den Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">task</span> zu

- Beobachte dabei die Bereiche "Todo" und "Erledigt" wenn du die Checkboxen benutzt.

---

<!-- .slide: style="text-align:left;font-size:35px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 07 Der Bereich "Journal"

- Erstellen des Bereichs "Journal" mit Tag: <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Inhalt</span>

```
Titel       : Journal
Neuer Tag   : Inhalt
Typ         : -
Text        :
```

- Nun wird beim Erstellen eines neuen Tiddlers vom Typ "Journal" automatisch ein Tiddler mit dem aktuellen Datum und dem Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Journal</span> erzeugt, in den wir unser "Tages-Journal" schreiben können. - Demo

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 08 Umgang mit Bildern

- Bilder können ganz einfach per Drag & Drop zum Wiki hinzugefügt werden.
- Sie sollten ihren Bildern immer einen Tag hinzufügen, z.B. <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">image</span> und den Namen ggf. anpassen.
- "Bild-Tiddler" können mit folgendem Syntax in Tiddler eingefügt werden:

```
[img[Motovun Jack.jpg]]
[img[https://tiddlywiki.com/favicon.ico]]
[img[An explanatory tooltip|Motovun Jack.jpg]]
[img width=32 [Motovun Jack.jpg]]
[img width=32 class="tc-image" [Motovun Jack.jpg]]
{{Motovun Jack.jpg}}
```
- Mit dem Markdown-Plugin ist auch der Markdown-Syntax möglich
- Es wird immer der Name des Bild-Tiddlers angegeben
- Der "Transclusion-Syntax" "`{{Jack.jpg}}`" erlaubt keine Zusatzparameter - Demo

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 09 Der Bereich "SysTools"

- "SysTools" Tiddler im Bereich "Inhalt" mit dem Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Inhalt</span>

```
Titel : SysTools
Tag   : Inhalt
Text  :
<!-- copy below here -->
<$list filter='[!has[draft.of]tag[SysTools]sort[title]]'>
<$link to={{!!title}}>
<$view field='title'/><br>
</$link>
</$list>
<!-- copy above here -->
```

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 09a "* BILDER zeige Systembilder"

- "* BILDER zeige Systembilder" Tiddler mit dem Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">SysTools</span>

```
Titel : * BILDER zeige Systembilder
Tag   : SysTools
Typ   : -
Text  :
<!-- copy below here -->
<table>
<tr>
<th>Schatten-Tiddler Name</th>
<th>gerendertes Bild</th>
</tr>
<$list filter="[all[shadows]sort[title]prefix[$:/core/ui/Buttons/]]" variable=info>
<tr>
<td><$link to=<<info>>></$link></td>
<td><$transclude tiddler=<<info>>/></td>
</tr>
</$list>
</table>

<table>
<tr>
<th>Schatten-Tiddler Name</th>
<th>Gerendertes Bild</th>
</tr>
<$list filter="[all[shadows]sort[title]prefix[$:/core/images/]]" variable=info>
<tr>
<td><$link to=<<info>>></$link></td>
<td><$transclude tiddler=<<info>>/></td>
</tr>
</$list>
</table>
<!-- copy above here -->
```

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 09b "* BILDER zeige importierte Bilder"

- "* BILDER zeige importierte Bilder" Tiddler mit dem Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">SysTools</span>

```
Title       : * BILDER zeige importierte Bilder
tag name(s) : SysTools
Typ   : -
Text        :
<!-- copy below here -->
<table>
<tr>
<th>Tiddler Name</th>
<th>Image rendered</th>
</tr>
<$list filter="[!has[draft.of]tag[image]sort[created]]" variable=info>
<tr>
<td><$link to=<<info>>></$link></td>
<td><$transclude tiddler=<<info>>/></td>
</tr>
</$list>
</table>
<!-- copy above here -->
```

---

<!-- .slide: style="text-align:left;font-size: 30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 09c "* TIDDLER ohne Verschlagwortung"

- "* TIDDLER ohne Verschlagwortung" Tiddler mit dem Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">SysTools</span>

```
Title       : * TIDDLER ohne Verschlagwortung
tag name(s) : SysTools
Typ   : -
Text        :
<!-- copy below here -->
<table>
<tr>
<th>Tiddlers without Tags</th>
</tr>
<$list  filter="[untagged[]!prefix[$:]]" variable=info>
<tr>
<td><$link to=<<info>>></$link></td>
</tr>
</$list>
</table>
<!-- copy above here -->
```

---

<!-- .slide: style="text-align:left;font-size: 35px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 10 Der Bereich "Dokumentationen"

- Wir erstellen einen neuen Tiddler "Dokumentationen" mit dem Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Inhalt</span>

```
Title       : Dokumentationen
tag name(s) : Inhalt
Typ         : -
Text        :
```

Alle zukünftigen Tiddler denen wir den Tag <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">Dokumentationen</span> zuweisen erscheinen unter "Dokumentationen".

---

<!-- .slide: style="text-align:left;font-size: 30px" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 11+12  Farbige Stempel + Markdown-Tabellen-Stempel

- Man kann in den TiddlyWiki-Editor eigene Stempel integrieren
- Es sind `/prefix` und `/suffix` Stempel möglich
- Zwecks Übersichtlichkeit sollte auch den Stempeln ein Tag zugwiesen werden, z.B. <span style="tab-size: 4;text-rendering: optimizeLegibility;word-wrap: break-word;display: inline-block;padding: 0.16em 0.7em;font-size: 0.6em;font-weight: normal;line-height: 1.2em;white-space: nowrap;vertical-align: baseline;background-color: #ec6;border-radius: 1em;fill: rgb(51, 51, 51);color: rgb(51, 51, 51);transition: none 0s ease 0s;transform: none;opacity: 1;">STEMPEL</span>
- In den Unterlagen befindet sich die Datei `stempel.json` mit allen im Demo benutzten Stempeln
- https://github.com/boschkundendienst/linux-cafe-april-2022.git
- Demo

---

<!-- .slide: style="text-align:left;font-size: 35px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 13  Eine Auswahl von Tiddlern exportieren

- Mit dem Werkzeug "Tools → Erweiterte Suche" lässt sich sehr schnell eine Auswahl an Tiddlern exportieren
- Am besten mit einem "Filter" arbeiten, z.B. `[tag[STEMPEL]]`
- Mit dem kleinen Export-Icon <svg width="22pt" color="white" height="22pt" viewBox="0 0 128 128"><path fill="#fff" fill-rule="evenodd" d="M8.003 128H119.993a7.984 7.984 0 005.664-2.349v.007A7.975 7.975 0 00128 120V56c0-4.418-3.59-8-8-8-4.418 0-8 3.58-8 8v56H16V56c0-4.418-3.59-8-8-8-4.418 0-8 3.58-8 8v64c0 4.418 3.59 8 8 8h.003zm48.62-100.689l-8.965 8.966c-3.125 3.125-8.195 3.13-11.319.005-3.118-3.118-3.122-8.192.005-11.319L58.962 2.346A7.986 7.986 0 0164.625 0l-.006.002c2.05-.001 4.102.78 5.666 2.344l22.618 22.617c3.124 3.125 3.129 8.195.005 11.319-3.118 3.118-8.192 3.122-11.319-.005l-8.965-8.966v61.256c0 4.411-3.582 8-8 8-4.41 0-8-3.582-8-8V27.311z"></path></svg> können dann alle gefilterten Tiddler auf einmal in eine `.json`-Datei exportiert werden

- Demo

---

<!-- .slide: style="text-align:left;font-size: 35px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 14  Daten in Tiddlern

Es gibt 2 Standard-Formate:

- Wörterbuch-Tiddler (Dictionary Tiddler)
```
okt:31
nov:30
dez:31
```

- JSON-Tiddler
```
{"okt":31,"nov":30,"dez":31}
```
- Auslesen mit Transklusion, z.B.
```
{Tiddlername##okt}} → 31
{Tiddlername##nov}} → 30
{Tiddlername##dez}} → 31
```
- Demo

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 15 Die Startseite

TiddlyWiki kann automatisch ein Inhaltsverzeichnis (TOC) generieren

- Erstelle folgenden Tiddler mit dem Namen "Startseite"
```
Title: Startseite
Tag: -
Typ: -

<!-- copy below -->
<div class="tc-table-of-contents">
<<toc-expandable "Inhalt" "sort[title]">>
</div>
<!-- copy above -->
```

- Dieser Tiddler zeigt automatisch alle mit dem Tag "Inhalt" versehenen Tiddler an.

- Diese "Startseite" kannst Du nun auch in den TiddlyWiki-Grundeinstellungen als "Standard-Tiddler" festlegen
- Demo

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 16 Tutorial in "Play with Docker" ausprobieren

Für dieses Tutorial wurde eigens ein Github Repo geschaffen. Es enthält alles was man benötigt um ein TiddlyWiki beim Dienst [Play with Docker](https://labs.play-with-docker.com/) laufen zu lassen (4h Limit).

Klone dazu einfach das Repo und arbeite im enthaltenen TiddlyWiki <font color="yellow">(presentation/files/linux-cafe-04-2022.html)</font> einfach den Punkt 16 ab

Demo

---

<!-- .slide: style="text-align:left;font-size:30px;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

## 17 Weiterführende Informationen

[TiddlyWiki Homepage](https://tiddlywiki.com/)

[TiddlyWiki Upgrader](https://tiddlywiki.com/upgrade.html)

[Deutsche Version von Tiddlywiki herunterladen](https://tiddlywiki.com/static/Deutsch%2520(Deutschland)%2520Edition.html)

 [A Gentle Guide to TiddlyWiki](https://tiddlywiki.com/#A%20Gentle%20Guide%20to%20TiddlyWiki)

[TW5 Magick - TiddlyWiki Tricks](http://tw5magick.tiddlyspot.com/)

[Die Seitenleiste beim Start automatisch ausblenden](https://tobibeer.github.io/tb5/#Hiding%20The%20Sidebar%20On%20Startup)

[Videos von Francis Meetze](https://www.youtube.com/channel/UCCYN_nzlUKKMiTj5rerv2lQ)

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

# The End

<div style="tab-size: 4;text-rendering: optimizeLegibility;line-height: 20px;word-wrap: break-word;color: #333333;fill: #333333;box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);position: relative;margin-bottom: 28px;background-color: #ffffff;border: 1px solid #ffffff;padding: 28px 42px 42px 42px;border-radius: 2px;width: 100%;transition: none 0s ease 0s;opacity: 1;"><br><br><br>&#060;tiddlywiki&#062;The End&#060;/tiddlywiki&#062;<br><br><br></div>

---

<!-- .slide: style="text-align:left;" data-background-image="images/puzzle2.jpg" data-background-size="960x 700x" -->

# Q & A

<div style="tab-size: 4;text-rendering: optimizeLegibility;line-height: 20px;word-wrap: break-word;color: #333333;fill: #333333;box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);position: relative;margin-bottom: 28px;background-color: #ffffff;border: 1px solid #ffffff;padding: 28px 42px 42px 42px;border-radius: 2px;width: 100%;transition: none 0s ease 0s;opacity: 1;"><br><br><br>&#060;tiddlywiki&#062;Fragerunde&#060;/tiddlywiki&#062;<br><br><br></div>